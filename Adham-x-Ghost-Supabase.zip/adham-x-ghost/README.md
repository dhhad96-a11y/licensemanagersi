# Adham x Ghost — starter project

واجهة متجر سوداء + Next.js + Supabase. هذه نسخة تأسيسية قابلة للتطوير؛ الربط الفعلي يحتاج مشروع Supabase ومفاتيحه وإكمال إجراءات الإدارة الآمنة.

## 1) إنشاء قاعدة البيانات
1. افتح https://supabase.com وأنشئ مشروعًا جديدًا.
2. من SQL Editor شغّل كامل ملف `supabase/schema.sql`.
3. من Project Settings → API انسخ Project URL وPublishable/anon key.
4. أنشئ مستخدم المالك من Authentication → Users. بعد ذلك انسخ UUID الخاص به ونفّذ في SQL Editor:

```sql
insert into public.profiles(id, username, role, balance)
values ('AUTH-USER-UUID-HERE', 'Adham x Ghost', 'owner', 0);
```

مهم: كلمة مرور المالك التي طلبتها هي `Adham x Ghost`، لكن لا تضعها في كود الموقع. أنشئ المستخدم من لوحة Supabase بكلمة مرور مناسبة. إذا احتجت كلمة المرور نفسها حرفيًا، تحقق من أن سياسة Supabase تسمح بها؛ كلمة المرور القوية والفريدة أكثر أمانًا.

## 2) الإعداد والتشغيل
1. انسخ `.env.example` إلى `.env.local`.
2. أدخل `NEXT_PUBLIC_SUPABASE_URL` و`NEXT_PUBLIC_SUPABASE_ANON_KEY`.
3. ثبّت Node.js ثم شغّل `npm install` وبعدها `npm run dev`.
4. للنشر: ارفع المشروع إلى GitHub، ثم استورده من Vercel وأضف متغيرات البيئة نفسها في Project Settings → Environment Variables.

## مهم قبل الإنتاج
- لا تضف `SUPABASE_SERVICE_ROLE_KEY` إلى متغير يبدأ بـ `NEXT_PUBLIC_` أو إلى أي كود متصفح.
- دالة شراء المنتج في SQL تخصم سعر المنتج وتخصص كودًا في معاملة واحدة. السعر الافتراضي $1؛ السعر الفعلي يقرأ من سجل المنتج.
- واجهات إنشاء المستخدمين، تعديل رصيد الحسابات، منح/سحب الصلاحيات، حذف الحسابات، وحذف الأكواد تحتاج إكمال Server Actions/Edge Functions والتحقق من دور المالك على الخادم قبل استخدامها في متجر عام. الواجهة المعروضة هي أساس التصميم وليست نظامًا جاهزًا للإنتاج دون تلك الخطوة.
- اسم المستخدم في Supabase Auth يستخدم البريد الإلكتروني. هذه النسخة تولّد عنوانًا محليًا بالشكل `username@adhamxghost.local` لتجربة الدخول؛ إعداد تسجيل الدخول النهائي يحتاج اختيار طريقة دخول مناسبة وإعدادها واختبارها.

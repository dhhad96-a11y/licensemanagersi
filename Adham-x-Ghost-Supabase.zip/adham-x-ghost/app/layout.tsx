import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Adham x Ghost | Code Market', description: 'متجر أكواد وبائعين بإدارة آمنة' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}

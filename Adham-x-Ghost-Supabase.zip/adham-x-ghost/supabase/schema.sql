-- Adham x Ghost database schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;
create type public.account_role as enum ('owner','seller','customer');
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique,
 role public.account_role not null default 'customer',
 balance numeric(12,2) not null default 0 check (balance >= 0),
 can_create_accounts boolean not null default false,
 can_manage_products boolean not null default false,
 can_manage_keys boolean not null default false,
 created_at timestamptz not null default now()
);
create table public.products (
 id uuid primary key default gen_random_uuid(), name text not null,
 description text, price numeric(12,2) not null default 1 check (price > 0),
 active boolean not null default true, created_by uuid references auth.users(id), created_at timestamptz not null default now()
);
create table public.license_keys (
 id uuid primary key default gen_random_uuid(), code text not null unique,
 product_id uuid references public.products(id) on delete set null,
 status text not null default 'available' check (status in ('available','sold','disabled')),
 owner_id uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now()
);
create table public.purchases (
 id uuid primary key default gen_random_uuid(), buyer_id uuid not null references auth.users(id),
 product_id uuid not null references public.products(id), key_id uuid not null unique references public.license_keys(id),
 amount numeric(12,2) not null, created_at timestamptz not null default now()
);
create table public.balance_transactions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id),
 amount numeric(12,2) not null, reason text not null, actor_id uuid references auth.users(id), created_at timestamptz not null default now()
);
create index on public.license_keys(product_id,status); create index on public.purchases(buyer_id,created_at desc);

create or replace function public.is_owner() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from profiles where id=auth.uid() and role='owner') $$;
create or replace function public.can_accounts() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from profiles where id=auth.uid() and (role='owner' or can_create_accounts)) $$;
create or replace function public.can_products() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from profiles where id=auth.uid() and (role='owner' or can_manage_products)) $$;
create or replace function public.can_keys() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from profiles where id=auth.uid() and (role='owner' or can_manage_keys)) $$;

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.license_keys enable row level security;
alter table public.purchases enable row level security;
alter table public.balance_transactions enable row level security;
create policy "read own profile or owner" on public.profiles for select to authenticated using (id=auth.uid() or public.is_owner());
create policy "read active products" on public.products for select to authenticated using (active or public.is_owner());
create policy "read own purchased keys or manager" on public.license_keys for select to authenticated using (owner_id=auth.uid() or public.can_keys() or public.is_owner());
create policy "read own purchases or owner" on public.purchases for select to authenticated using (buyer_id=auth.uid() or public.is_owner());
create policy "read own transactions or owner" on public.balance_transactions for select to authenticated using (user_id=auth.uid() or public.is_owner());
revoke all on public.profiles, public.products, public.license_keys, public.purchases, public.balance_transactions from anon;
grant select on public.profiles, public.products, public.license_keys, public.purchases, public.balance_transactions to authenticated;

-- Atomically charge exactly the listed product price and assign one available key.
create or replace function public.purchase_product(p_product_id uuid) returns text language plpgsql security definer set search_path=public as $$
declare v_user uuid:=auth.uid(); v_price numeric(12,2); v_key public.license_keys%rowtype; v_balance numeric(12,2);
begin
 if v_user is null then raise exception 'يجب تسجيل الدخول أولاً'; end if;
 select price into v_price from products where id=p_product_id and active=true for share;
 if v_price is null then raise exception 'المنتج غير متاح'; end if;
 select balance into v_balance from profiles where id=v_user for update;
 if v_balance is null then raise exception 'الحساب غير مكتمل'; end if;
 if v_balance < v_price then raise exception 'رصيدك غير كافٍ'; end if;
 select * into v_key from license_keys where product_id=p_product_id and status='available' for update skip locked limit 1;
 if v_key.id is null then raise exception 'نفدت أكواد هذا المنتج'; end if;
 update profiles set balance=balance-v_price where id=v_user;
 update license_keys set status='sold', owner_id=v_user where id=v_key.id;
 insert into purchases(buyer_id,product_id,key_id,amount) values(v_user,p_product_id,v_key.id,v_price);
 insert into balance_transactions(user_id,amount,reason) values(v_user,-v_price,'شراء منتج');
 return v_key.code;
end; $$;

create or replace function public.admin_add_product(p_name text,p_description text,p_price numeric default 1) returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin if not public.can_products() then raise exception 'ليست لديك صلاحية إضافة المنتجات'; end if;
 if trim(p_name)='' or p_price<=0 then raise exception 'بيانات المنتج غير صحيحة'; end if;
 insert into products(name,description,price,created_by) values(trim(p_name),nullif(trim(p_description),''),p_price,auth.uid()) returning id into v_id; return v_id; end; $$;
create or replace function public.admin_add_key(p_product_id uuid,p_code text) returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin if not public.can_keys() then raise exception 'ليست لديك صلاحية إضافة الأكواد'; end if;
 if trim(p_code)='' then raise exception 'الكود لا يمكن أن يكون فارغاً'; end if;
 insert into license_keys(code,product_id) values(trim(p_code),p_product_id) returning id into v_id; return v_id; end; $$;

-- Create the owner profile after creating the owner's Auth user in Supabase Dashboard.
-- Replace the UUID and username with the real Auth user ID and desired username.
-- Never put the service-role key in browser code or commit it to GitHub.

import { createClient } from '@supabase/supabase-js';
export function supabasePublic() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error('أضف إعدادات Supabase إلى متغيرات البيئة أولاً.');
  return createClient(url, key);
}

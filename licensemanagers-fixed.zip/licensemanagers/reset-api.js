/**
 * Simple FLOURITE reset API bridge
 * POST /api/reset  { "keyCode": "16CHARKEYHERE" }
 *
 * Usage:
 *   TELEGRAM_BOT_TOKEN=xxx TELEGRAM_ADMIN_CHAT_ID=xxx node reset-api.js
 */
const http = require('http');

const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const ADMIN_CHAT = process.env.TELEGRAM_ADMIN_CHAT_ID || '';

async function sendReset(keyCode) {
  if (!BOT_TOKEN) return { success: false, error: 'TELEGRAM_BOT_TOKEN not set' };
  if (!ADMIN_CHAT) return { success: false, error: 'TELEGRAM_ADMIN_CHAT_ID not set' };
  const command = '/reset ' + keyCode;
  const url = 'https://api.telegram.org/bot' + BOT_TOKEN + '/sendMessage';
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: ADMIN_CHAT, text: command })
  });
  const data = await res.json();
  if (!data.ok) return { success: false, error: data.description || 'Telegram error' };
  return {
    success: true,
    message: 'Reset command sent for ' + keyCode,
    messageId: data.result && data.result.message_id
  };
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  if (req.method === 'POST' && (req.url === '/api/reset' || req.url.startsWith('/api/reset?'))) {
    let body = '';
    for await (const chunk of req) body += chunk;
    try {
      const parsed = JSON.parse(body || '{}');
      const keyCode = parsed.keyCode || parsed.key || '';
      if (!keyCode || !/^[A-Za-z0-9]{16}$/.test(keyCode)) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Invalid keyCode (need 16 alphanumeric)' }));
        return;
      }
      const result = await sendReset(String(keyCode).toUpperCase());
      res.writeHead(result.success ? 200 : 500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: String(e.message || e) }));
    }
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found. POST /api/reset' }));
});

server.listen(PORT, () => console.log('FLOURITE reset API on http://localhost:' + PORT));

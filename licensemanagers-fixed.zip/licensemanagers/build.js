#!/usr/bin/env node
/**
 * Build script: reads src/full_app.html + src/pages/*.html
 * Encodes everything as base64 and writes dist/index.html loader.
 */
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname);
const pagesDir = path.join(root, 'src', 'pages');
const fullPath = path.join(root, 'src', 'full_app.html');
const distDir = path.join(root, 'dist');

if (!fs.existsSync(distDir)) fs.mkdirSync(distDir, { recursive: true });

const full = fs.readFileSync(fullPath, 'utf8');
const pageParts = {};
for (const f of fs.readdirSync(pagesDir).filter(x => x.endsWith('.html'))) {
  const id = f.replace(/\.html$/, '');
  pageParts[id] = Buffer.from(fs.readFileSync(path.join(pagesDir, f), 'utf8'), 'utf8').toString('base64');
}

const fullB64 = Buffer.from(full, 'utf8').toString('base64');
const chunkSize = 120;
const chunks = [];
for (let i = 0; i < fullB64.length; i += chunkSize) chunks.push(fullB64.slice(i, i + chunkSize));

const loader = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta name="robots" content="noindex, nofollow">
<title>Secure Loader — License Managers</title>
<style>
html,body{margin:0;padding:0;background:#06040e;color:#f5eeff;font-family:monospace;height:100%}
#boot{display:flex;align-items:center;justify-content:center;height:100vh;flex-direction:column;gap:12px}
#boot .spin{width:40px;height:40px;border:3px solid rgba(180,60,255,.3);border-top-color:#bf5eff;border-radius:50%;animation:s 1s linear infinite}
@keyframes s{to{transform:rotate(360deg)}}
</style>
</head>
<body>
<div id="boot"><div class="spin"></div><div>Assembling secure session…</div></div>
<script>
(function(){
  "use strict";
  var PAGE_PARTS = ${JSON.stringify(pageParts)};
  var parts = ${JSON.stringify(chunks)};
  function b64ToUtf8(str) {
    try { return decodeURIComponent(escape(atob(str))); } catch (e) { return atob(str); }
  }
  try {
    var html = b64ToUtf8(parts.join(''));
    Object.keys(PAGE_PARTS).forEach(function(k){ try { b64ToUtf8(PAGE_PARTS[k]); } catch(e) {} });
    document.open();
    document.write(html);
    document.close();
  } catch (err) {
    document.getElementById('boot').innerHTML = '<div style="color:#f87171">Load failed</div><pre>'+String(err)+'</pre>';
  }
})();
</script>
</body>
</html>`;

fs.writeFileSync(path.join(distDir, 'index.html'), loader);
console.log('Built dist/index.html (' + loader.length + ' bytes, ' + chunks.length + ' chunks, ' + Object.keys(pageParts).length + ' pages)');

# License Managers — FULL FIXED PROJECT

## What was fixed

1. **Duration editor (Add/Edit Product)**  
   - Amount + **Hour / Day** select + Price  
   - Labels show exactly: `1 Hour`, `3 Hours`, `3 Days`, etc.

2. **Generated Keys ✅ icon**  
   - Check mark is centered inside the circle

3. **Devil Xit Proxy product**  
   - Exact prices from the photo (1h–30d)  
   - Included in default products + products_seed.json

4. **Duration display everywhere**  
   - Uses real labels instead of only `Xd`

## Deploy (Vercel)

1. Use `dist/index.html` as site root  
2. Root Directory: `dist` **OR** upload only the `dist` folder  
3. Domain lock: **licensemanagers.vercel.app** only

## Quick add product to live Firebase

Open `add-devil-xit-proxy.html` in a browser → one click → product written to your Firebase DB.

## Structure

```
license_project/
├── dist/index.html          ← deploy this (loader + encoded app)
├── dist/app.html            ← direct full app (no loader)
├── dist/index-direct.html   ← same as app.html
├── src/full_app.html        ← source (all fixes live here)
├── src/products_seed.json
├── src/pages/
├── backend/
├── add-devil-xit-proxy.html ← one-click add to Firebase
├── build.js                 ← rebuild dist from src/full_app.html
├── reset-api.js
└── README.md
```

## Rebuild after editing source

```bash
node build.js
```

## FLOURITE reset API

```bash
export TELEGRAM_BOT_TOKEN="..."
export TELEGRAM_ADMIN_CHAT_ID="..."
node reset-api.js
```

```js
localStorage.setItem('flourite_reset_api', 'https://your-api-host');
```
